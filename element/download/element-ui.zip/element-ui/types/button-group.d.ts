import { ElementUIComponent } from './component'

/** Button Group Component */
export declare class ElButtonGroup extends ElementUIComponent {}
